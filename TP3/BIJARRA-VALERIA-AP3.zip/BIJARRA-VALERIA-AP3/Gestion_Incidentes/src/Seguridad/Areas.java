package Seguridad;

public class Areas {

}
