_________________________________________________________________

usuario:   EBIONDINI
clave: 123

resolutor:  GLAZARINI
clave: 123
_________________________________________________________________
soluciones usuario
_________________________________________________________________
sistema:  [1] Sys_Admin
modulo:   [2] Pagos
proceso:  [3] Ingreso Pagos
pantalla: [5] Pago

despliega solucion de usuario 1 y 2
 
_________________________________________________________________
soluciones tecnicas 
_________________________________________________________________
aplicacion: [1] Sys_Admin
modulo:     [1] Administraci�n
proceso:    [1] Ingreso Facturas
pantalla:   [1] Factura

despliega solución tecnica nro 3